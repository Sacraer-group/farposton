"""Read-only verification of every known offer against the deployed app."""
import concurrent.futures
import datetime
import hashlib
import json
from pathlib import Path
import urllib.error
import urllib.request

from bs4 import BeautifulSoup

ROOT = Path(__file__).resolve().parents[1]


def check(offer):
    url = offer['app_url']
    row = {'source': offer['source'], 'source_id': offer['source_id'],
           'url': url, 'checked_at': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    try:
        with urllib.request.urlopen(url, timeout=35) as response:
            body = response.read()
            row['http_status'] = response.status
        path = ROOT / 'raw' / 'catalog' / (offer['group_id'] + '.html')
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(body)
        soup = BeautifulSoup(body, 'html.parser')
        main = soup.find('main')
        row['title'] = soup.title.get_text(' ', strip=True) if soup.title else None
        row['source_ids_on_page'] = sorted(set(x.get('value') for x in soup.select('input[name=source_id]')))
        row['source_id_verified'] = offer['source_id'] in row['source_ids_on_page']
        row['import_status'] = soup.select_one('.import-status').get_text(' ',strip=True)
        row['page_sha256'] = hashlib.sha256(body).hexdigest()
        row['page_text'] = main.get_text('\n', strip=True) if main else ''
    except Exception as exc:
        row['error'] = type(exc).__name__ + ': ' + str(exc)
    return row


if __name__ == '__main__':
    addresses = json.loads((ROOT / 'addresses.json').read_text())
    offers = [o for b in addresses for o in b['offers']]
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        rows = list(pool.map(check, offers))
    (ROOT / 'catalog_verification.json').write_text(json.dumps(rows, ensure_ascii=False, indent=2))
    print(json.dumps({'requested': len(rows), 'http_200': sum(r.get('http_status')==200 for r in rows),
                      'source_id_verified':sum(r.get('source_id_verified',False) for r in rows),
                      'errors':[{'source_id':r['source_id'],'error':r.get('error')} for r in rows if r.get('http_status')!=200]},ensure_ascii=False))
