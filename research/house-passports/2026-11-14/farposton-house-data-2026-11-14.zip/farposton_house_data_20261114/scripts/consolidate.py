"""Consolidate the observed house data and check referential completeness."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def read(name):
    return json.loads((ROOT / name).read_text(encoding='utf-8'))


def dump(name, data):
    (ROOT / name).write_text(json.dumps(data, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')


def md(value):
    return str(value).replace('|', '\\|').replace('\n', ' ')


def main():
    addresses=read('addresses.json')
    expected={x['building_key'] for x in addresses}
    assert len(addresses)==len(expected)==48
    names=['vl_house_mapping','management','outages','repairs','coordinates']
    tables={}
    for name in names:
        rows=read('parts/'+name+'.json')
        assert len(rows)==len({x['building_key'] for x in rows})==48, name
        assert {x['building_key'] for x in rows}==expected, name
        tables[name]={x['building_key']:x for x in rows}
    live=read('catalog_verification.json')
    assert len(live)==50 and all(r.get('source_id_verified') and r.get('http_status')==200 for r in live)
    offer_keys={(o['source'],o['source_id']) for h in addresses for o in h['offers']}
    assert len(offer_keys)==50
    assert offer_keys=={(r['source'],r['source_id']) for r in live}
    assert len({r['vl_house_id'] for r in tables['vl_house_mapping'].values()})==48

    houses=[]
    floor_conflicts=[]
    municipal_check=read('parts/municipal_source_check.json')
    for base in addresses:
        k=base['building_key']
        mapping=tables['vl_house_mapping'][k]
        management=tables['management'][k]
        outages=tables['outages'][k]
        repairs=tables['repairs'][k]
        coordinates=tables['coordinates'][k]
        assert mapping['match_status']=='matched'
        assert coordinates['status']=='found' and coordinates['matched_address']==mapping['matched_address']
        assert outages['requested_period_complete'], k
        assert len(outages['events'])==len({e['source_event_id'] for e in outages['events']}), k
        assert len(repairs['execution_checks'])==10, k
        flags=[]
        if management.get('management_status')=='conflict_unresolved':
            flags.append({'kind':'management_conflict','evidence':management.get('conflicts',[])})
        if management.get('management_status')=='not_found_in_checked_sources':
            flags.append({'kind':'management_not_found','note':'No exact organization relationship found in checked sources.'})
        fkr_floor=repairs.get('building_fields',{}).get('floors_total',{}).get('value')
        listing_floors=sorted({o['floors_total'] for o in base['offers'] if o.get('floors_total') is not None})
        if fkr_floor is not None and any(n!=fkr_floor for n in listing_floors):
            flag={'kind':'floors_disagreement','official_programme_value':fkr_floor,
                  'listing_values':listing_floors,'note':'Different source observations; not proof which value is wrong.'}
            flags.append(flag);floor_conflicts.append({'building_key':k,**flag})
        if repairs['match_status']!='found':
            flags.append({'kind':'regional_programme_not_matched','note':'No exact match in the downloaded programme; no conclusion about repair obligations.'})
        if any(x.get('status')=='source_unavailable' for x in repairs.get('execution_checks',[])):
            flags.append({'kind':'repair_execution_coverage_gap','note':'Some public source requests returned 403; missing data retained as unknown.'})
        houses.append({**base,'vl_match':mapping,'management':management,'outages':outages,
                       'repairs':repairs,'map_coordinates':coordinates,'quality_flags':flags,
                       'utility_bill_evidence':{'status':'not_available','reason':'No anonymized utility bills were supplied. Listing payment conditions are retained per offer.'},
                       'resident_problem_evidence':{'status':'no_independently_verified_records','published_map_claims':coordinates.get('published_current_claims',[]),
                           'note':'No independent resident confirmation was obtained. An empty source map claim list is not evidence that the house has no problems.'},
                       'municipal_projects':{'status':'not_assessed','source_check':municipal_check,
                           'note':'The preliminary official municipal source was unavailable. No comprehensive address-level coverage of yard improvements, street work or route changes is claimed. Capital repairs are recorded separately.'}})

    events=[e for h in houses for e in h['outages']['events']]
    work_rows=[w for h in houses for w in h['repairs']['works']]
    m_counts=Counter(h['management']['management_status'] for h in houses)
    r_summary=read('parts/repairs_summary.json')
    summary={
        'live_offer_pages_verified':50,'unique_houses':48,'vl_exact_house_matches':48,'map_coordinates_obtained':48,
        'houses_with_management_claim':sum(any(o.get('role')=='Управляющая организация' for o in h['management']['organizations']) for h in houses),
        'management_status_counts':dict(m_counts),'primary_management_contracts_verified':0,
        'official_regional_programme_matches':sum(h['repairs']['match_status']=='found' for h in houses),
        'outage_house_event_relations':len(events),'distinct_outage_source_publications':len({e['source_event_id'] for e in events}),
        'outage_requested_period_complete':sum(h['outages']['requested_period_complete'] for h in houses),
        'outage_all_time_history_complete':sum(h['outages']['all_time_history_complete'] for h in houses),
        'additional_explicitly_older_outage_records':sum(h['outages']['additional_explicitly_older_records'] for h in houses),
        'outage_count_note':'Counts include older supplemental records and repeated publication-to-house links. They are not counts of distinct real outages during the last year.',
        'regional_work_observations':r_summary['regional_work_observations'],
        'short_term_houses':r_summary['short_term_houses'],'short_term_work_observations':r_summary['short_term_work_observations'],
        'execution_houses_with_work_rows':r_summary['execution_houses_with_work_rows'],
        'execution_work_observations':r_summary['execution_work_observations'],
        'execution_work_rows_reported_complete':r_summary['execution_work_rows_reported_complete'],
        'execution_work_rows_without_reported_completion':r_summary['execution_work_rows_without_reported_completion'],
        'repair_execution_house_year_gaps':r_summary['execution_check_statuses']['source_unavailable'],
        'floors_source_conflicts':floor_conflicts,
        'utility_bills_available':0,
        'independently_verified_resident_problems':0,
        'municipal_project_coverage':'not_established',
    }
    manifest=read('manifest.json')
    manifest.update({'consolidated_at_utc':datetime.now(timezone.utc).isoformat(),
                     'local_snapshot_date':'2026-11-14','local_time_zone':'Asia/Vladivostok',
                     'outage_requested_period':houses[0]['outages']['requested_period'],
                     'architecture_status':'design_and_task_contracts; not deployed',
                     'source_snapshot_sha256':{n:hashlib.sha256((ROOT/'parts'/(n+'.json')).read_bytes()).hexdigest() for n in names}})
    dump('manifest.json',manifest)
    dump('house_passports.json',{'schema_version':1,'manifest':manifest,'summary':summary,'houses':houses})
    dump('summary.json',summary)
    dump('validation.json',{'checked_at':datetime.now(timezone.utc).isoformat(),
                          'result':'passed','checks':['50 deployed source IDs verified','48 unique address keys in every input section',
                          '48 distinct VL house IDs','48 map house names match address mapping','48 requested history periods traversed',
                          'No duplicate event IDs within a house','10 repair execution years checked per house',
                          'All 50 offer keys preserved','Unknown and conflicting source values preserved'],
                          'offer_count':50,'house_count':48})
    coverage=['# Покрытие данных по всем адресам', '',
              'Срез собран 14 ноября 2026 года по Владивостоку. Все 50 карточек проверены на работающем сайте; в них 48 уникальных адресов.', '',
              '**Записи истории ниже — все собранные записи, включая более старые дополнения. Это не число отключений за год.**', '',
              '| Ключ | Адрес | Квартир | Опубликованная УК / ТСЖ | Статус УК | ФКР | Записей истории |',
              '|---|---|---:|---|---|---|---:|']
    statuses={'published_claim':'Опубликовано; первично не подтверждено','conflict_unresolved':'Противоречие источников','not_found_in_checked_sources':'Не найдена'}
    for h in houses:
        orgs=list(dict.fromkeys(o['name'] for o in h['management']['organizations'] if o.get('role')=='Управляющая организация'))
        coverage.append('| '+' | '.join(map(md,[h['building_key'],h['address'],len(h['offers']),'; '.join(orgs) or 'Не найдена',statuses[h['management']['management_status']],'Точное совпадение' if h['repairs']['match_status']=='found' else 'Не найден точный адрес',len(h['outages']['events'])]))+' |')
    coverage += ['', '## Ограничения', '',
                 '- УК и контакты получены преимущественно из вторичных адресных справочников; действующие договоры управления не подтверждены.',
                 '- Нет опубликованных записей в проверенной выборке не означает отсутствие отключений или ремонтов.',
                 '- План, сообщение о выполнении и фактическое состояние дома — разные сведения.',
                 '- Платежи из квитанций не собраны: обезличенных документов пользователя или жителей не было.',
                 '- Независимо подтверждённых проблем жителей нет; пустой список обращений на карте источника не доказывает отсутствие проблем.',
                 '- Полнота городских проектов, ремонта дворов и изменений маршрутов не установлена: предварительный официальный источник вернул 503. Капремонт проверялся отдельно.',
                 '- Привязка относится к адресу, указанному в объявлении; фактическое местонахождение квартиры просмотром не проверялось.',
                 '- Все происхождение полей, URL, даты, неизвестные значения и ошибки источников сохранены в house_passports.json.', '']
    (ROOT/'COVERAGE.ru.md').write_text('\n'.join(coverage),encoding='utf-8')
    print(json.dumps({k:v for k,v in summary.items() if k!='floors_source_conflicts'},ensure_ascii=False))


if __name__=='__main__':
    main()
