import importlib.util
import json
from pathlib import Path
import re
from bs4 import BeautifulSoup

ROOT=Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('collector',ROOT/'scripts/outages/collect_events.py')
collector=importlib.util.module_from_spec(spec)
spec.loader.exec_module(collector)
spec2=importlib.util.spec_from_file_location('matcher',ROOT/'scripts/outages/match_addresses.py')
matcher=importlib.util.module_from_spec(spec2)
spec2.loader.exec_module(matcher)

addresses=json.loads((ROOT/'addresses.json').read_text())
mapping=json.loads((ROOT/'parts/vl_house_mapping.json').read_text())
outages=json.loads((ROOT/'parts/outages.json').read_text())
assert {r['building_key'] for r in addresses}=={r['building_key'] for r in mapping}=={r['building_key'] for r in outages}
assert len(addresses)==len(mapping)==len(outages)==48
for row in mapping:
    assert row['match_status']=='matched',row['building_key']
    assert matcher.norm(row['requested_address'])==matcher.norm(row['matched_address'])==matcher.norm(row['page_title']),row['building_key']

errors=[]
for row in outages:
    key=row['building_key']
    ids={e['source_event_id'] for e in row['events']}
    assert len(ids)==len(row['events'])==row['event_count'],key
    for event in row['events']:
        assert event['source_event_id'] in event['source_url'],(key,event)
        assert event['published_at'] is None,(key,event)
    all_html_ids=set()
    for path in (ROOT/'raw/outages').glob(key+'_history_*.html'):
        soup=BeautifulSoup(path.read_text(),'html.parser')
        for li in soup.select('li.history__item'):
            links=li.select('a[href*="/off/blackout/"]')
            assert len(links)==1,(key,path,'missing or duplicate event reference')
            match=re.search(r'/off/blackout/(\d+)\.html',links[0]['href'])
            assert match,(key,path,'unparseable event reference')
            all_html_ids.add(match.group(1))
    if all_html_ids!=ids:
        errors.append({'building_key':key,'cached_not_structured':sorted(all_html_ids-ids),'structured_not_cached':sorted(ids-all_html_ids)})
    if row.get('requested_period_complete'):
        assert row.get('history_complete') or any(collector.explicit_older_date(e) for e in row['events']),key
    else:
        errors.append({'building_key':key,'period_incomplete':True})

summary={'buildings':len(outages),'exact_address_matches':len(mapping),'building_event_relations':sum(r['event_count'] for r in outages),
         'distinct_source_events':len({e['source_event_id'] for r in outages for e in r['events']}),
         'requested_period_complete':sum(r.get('requested_period_complete',False) for r in outages),
         'all_time_history_complete':sum(r.get('all_time_history_complete',False) for r in outages),
         'source_checks':sum(len(r['source_checks']) for r in outages),
         'html_record_parity_errors':errors}
(ROOT/'parts/outages_validation.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
print(json.dumps(summary,ensure_ascii=False,indent=2))
assert not errors,'Outage data validation has unresolved errors'
