import concurrent.futures
import datetime as dt
import json
from pathlib import Path
import re
import threading
import time
import urllib.parse
import urllib.request
from bs4 import BeautifulSoup

ROOT = Path(__file__).resolve().parents[2]
RAW = ROOT / 'raw/outages'
RAW.mkdir(parents=True, exist_ok=True)
LOCK = threading.Lock()
RESULTS = []

def now():
    return dt.datetime.now(dt.timezone.utc).isoformat()

def norm(s):
    s = s.lower().replace('ё', 'е')
    s = re.sub(r'\b(?:улица|проспект|переулок|пр-кт)(?=\s|$)|\b(?:ул|пер)\.(?=\s|$)', '', s)
    s = re.sub(r'\b(?:корпус(?=\s)|кор\.|корп\.)\s*', 'кор', s)
    return re.sub(r'[\s.,]+', '', s)

def get(url, filename, checks):
    if filename.exists():
        checks.append({'url': url, 'status': 'cached', 'checked_at': now()})
        return filename.read_bytes()
    try:
        with urllib.request.urlopen(url, timeout=30) as r:
            data = r.read()
            filename.write_bytes(data)
            checks.append({'url': url, 'status': r.status, 'checked_at': now()})
            return data
    except Exception as e:
        checks.append({'url': url, 'status': 'error', 'error': str(e), 'checked_at': now()})
        return None

def run(row):
    key = row['building_key']
    result = {'building_key': key, 'requested_address': row['address'], 'match_status': 'not_found', 'source_checks': []}
    query = re.sub(r'^(улица|проспект|переулок)\s+', '', row['address'])
    url = 'https://www.vl.ru/off/addresses/autocomplete?' + urllib.parse.urlencode({'query': query})
    raw = get(url, RAW / (key + '_suggestions.json'), result['source_checks'])
    if raw is None:
        result['match_status'] = 'blocked'
        return result
    try:
        suggestions = json.loads(raw).get('suggestions', [])
    except Exception as e:
        result['match_status'] = 'blocked'
        result['parse_error'] = str(e)
        return result
    result['suggestions'] = suggestions
    exact = [s for s in suggestions if norm(s['value']) == norm(row['address']) and s.get('slugs', {}).get('1')]
    if not exact:
        parts = re.match(r'^(улица|проспект|переулок)\s+(.+?)\s+(\d+[\w/]*(?:\s+кор\.\s*\d+)?)$', row['address'])
        if parts:
            kind, street, number = parts.groups()
            short_kind = {'улица':'ул.', 'проспект':'пр-кт', 'переулок':'пер.'}[kind]
            variants = [street + ' ' + short_kind + ' ' + number,
                        street + ' ' + short_kind + ' ' + re.sub(r'\s+кор\.\s*\d+$', '', number)]
            result['additional_lookups'] = []
            for index, variant in enumerate(dict.fromkeys(variants)):
                next_url = 'https://www.vl.ru/off/addresses/autocomplete?' + urllib.parse.urlencode({'query': variant})
                data = get(next_url, RAW / (key + f'_suggestions_variant{index}.json'), result['source_checks'])
                if data is None:
                    continue
                choices = json.loads(data).get('suggestions', [])
                result['additional_lookups'].append({'query':variant, 'suggestions':choices})
                exact = [s for s in choices if norm(s['value']) == norm(row['address']) and s.get('slugs', {}).get('1')]
                if exact:
                    break
    if len(exact) != 1:
        result['match_status'] = 'ambiguous' if exact else 'not_found'
        return result
    match = exact[0]
    slug = match['slugs']['1']
    building_url = 'https://www.vl.ru/off/' + slug + '.html'
    html = get(building_url, RAW / (key + '_building.html'), result['source_checks'])
    result.update({'matched_address': match['value'], 'building_url': building_url, 'match_basis': 'exact_normalized_street_number_suffix_corpus'})
    if html is None:
        result['match_status'] = 'blocked'
        return result
    soup = BeautifulSoup(html, 'html.parser')
    ids = set(re.findall(r'/off/b/(?:story|info|contacts)/(\d+)', html.decode('utf-8', 'replace')))
    h1 = soup.find('h1')
    result['page_title'] = h1.get_text(' ', strip=True) if h1 else None
    if len(ids) != 1:
        result['match_status'] = 'ambiguous'
        result['observed_house_ids'] = sorted(ids)
        return result
    house_id = ids.pop()
    result.update({'match_status': 'matched', 'vl_house_id': house_id, 'story_url': 'https://www.vl.ru/off/b/story/' + house_id, 'info_url': 'https://www.vl.ru/off/b/info/' + house_id, 'contacts_url': 'https://www.vl.ru/off/b/contacts/' + house_id})
    return result

def main():
    rows = json.loads((ROOT / 'addresses.json').read_text())
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        for result in pool.map(run, rows):
            RESULTS.append(result)
            target = ROOT / 'parts/vl_house_mapping.json'
            tmp = target.with_suffix('.tmp')
            tmp.write_text(json.dumps(RESULTS, ensure_ascii=False, indent=2))
            tmp.replace(target)
            print(result['building_key'], result['match_status'], result.get('vl_house_id'), result.get('matched_address'), flush=True)

if __name__ == '__main__':
    main()
