import concurrent.futures
import datetime as dt
import json
from pathlib import Path
import re
import sys
import threading
import time
import urllib.request
from bs4 import BeautifulSoup

ROOT = Path(__file__).resolve().parents[2]
RAW = ROOT / 'raw/outages'
LOCK = threading.Lock()
OUTPUT = ROOT / 'parts/outages.json'
RESULTS = {}
CUTOFF = dt.date(2025, 11, 14)
REQUESTED_PERIOD = {'from':'2025-11-14','through':'2026-11-14','timezone':'Asia/Vladivostok','basis':'event periods as displayed by source, not publication timestamps'}

def now():
    return dt.datetime.now(dt.timezone.utc).isoformat()

def save():
    with LOCK:
        tmp = OUTPUT.with_suffix('.tmp')
        tmp.write_text(json.dumps([RESULTS[k] for k in sorted(RESULTS)], ensure_ascii=False, indent=2))
        tmp.replace(OUTPUT)

def get(url, filename, checks):
    if filename.exists():
        checks.append({'url':url, 'status':'cached', 'fetched_at':dt.datetime.fromtimestamp(filename.stat().st_mtime,dt.timezone.utc).isoformat(), 'checked_at':now()})
        return filename.read_bytes()
    for attempt in range(2):
        try:
            with urllib.request.urlopen(url,timeout=30) as response:
                raw=response.read()
                filename.write_bytes(raw)
                checks.append({'url':url,'status':response.status,'fetched_at':now(),'checked_at':now()})
                return raw
        except Exception as exc:
            checks.append({'url':url,'status':'error','error':str(exc),'attempt':attempt+1,'checked_at':now()})
            if getattr(exc,'code',None) in (401,403,429):
                break
            time.sleep(1)
    return None

def text(node):
    return ' '.join(node.stripped_strings) if node else None

def explicit_older_date(event):
    value=event.get('period_as_published') or ''
    months={'янв':1,'фев':2,'мар':3,'апр':4,'мая':5,'май':5,'июн':6,'июл':7,'авг':8,'сен':9,'окт':10,'ноя':11,'дек':12}
    dates=[]
    for day, month, year in re.findall(r'(\d{1,2})\s+([а-яё]+)\.?\s+(20\d{2})',value,re.I):
        num=months.get(month[:3].lower())
        if num:
            try: dates.append(dt.date(int(year),num,int(day)))
            except ValueError: pass
    if dates and max(dates)<CUTOFF:
        return max(dates).isoformat()
    years=[int(y) for y in re.findall(r'\b20\d{2}\b',value)]
    if years and max(years)<CUTOFF.year:
        return str(max(years))+' (explicit year; exact day not parsed)'
    return None

def mark_coverage(record):
    record['requested_period']=REQUESTED_PERIOD
    record['all_time_history_complete']=record.get('history_complete',False)
    record['requested_period_complete']=False
    record['coverage_uncertain']=False
    record['coverage_note']='The source history is followed in its displayed order until an explicitly dated older record or its end. This does not establish completeness of real-world outages. Records without a year retain the original string; no year is invented.'
    if record.get('history_complete'):
        record['requested_period_complete']=True
        record['stop_reason']='source_history_exhausted'
    else:
        older=[(event,explicit_older_date(event)) for event in record.get('events',[])]
        older=[(event,date) for event,date in older if date]
        if older:
            record['requested_period_complete']=True
            record['stop_reason']='date_cutoff'
            record['cutoff_evidence']={'source_event_id':older[0][0]['source_event_id'],'period_as_published':older[0][0]['period_as_published'],'explicit_older_date':older[0][1]}
        else:
            record['coverage_uncertain']=True
    record['additional_explicitly_older_records']=sum(bool(explicit_older_date(e)) for e in record.get('events',[]))

def parse(raw, url):
    soup=BeautifulSoup(raw,'html.parser')
    events=[]
    for li in soup.select('li.history__item'):
        link=li.select_one('a[href*="/off/blackout/"]')
        if not link:
            continue
        match=re.search(r'/off/blackout/(\d+)\.html',link['href'])
        if not match:
            continue
        labels=[]
        for tip in li.select('.history-tooltip'):
            label=tip.select_one('.history-tooltip__label')
            if label:
                label_text=text(label)
                value=text(tip)
                labels.append({'label':label_text,'value':value[len(label_text):].strip()})
        additional=text(li.select_one('.building-resume__additional'))
        reason=re.sub(r'\s*\(\s*№\d+\s*\)\s*$', '',additional or '')
        period=text(li.select_one('.history-date__period'))
        category='emergency' if re.search(r'\bавари',reason,re.I) else ('planned' if re.search(r'\bпланов',reason,re.I) else None)
        event={'source_event_id':match.group(1),'resource':text(li.select_one('.history-type')),
               'period_as_published':period,'timeline_labels':labels,
               'house_duration_as_published':text(li.select_one('[title="время отключения дома"]')),
               'reason':reason,'organization_as_published':text(li.select_one('.building-resume__initiator')),
               'event_classification_from_explicit_text':category,
               'status_as_published':'Не закончено' if 'Не закончено' in text(li) else None,
               'source_url':'https://www.vl.ru'+link['href'],'history_page_url':url,
               'observed_at':now(), 'published_at':None,
               'date_note':'Dates retained as published. Omitted years are not inferred; source end label does not prove actual service restoration.'}
        events.append(event)
    button=soup.select_one('button.history__load-btn[data-url]')
    return events, ('https://www.vl.ru'+button['data-url']) if button else None

def fetch_first(mapping):
    key=mapping['building_key']
    if mapping['match_status']!='matched':
        return
    record=RESULTS[key]
    url=mapping['story_url']
    raw=get(url,RAW/(key+'_history_0.html'),record['source_checks'])
    if raw is None:
        record['status']='blocked'
    else:
        events,next_url=parse(raw,url)
        record.update({'status':'found','events':events,'event_count':len(events),'next_page_url':next_url,'history_complete':not bool(next_url),'pages_collected':1})
    save()
    print('first',key,record['status'],record.get('event_count',0),'more',bool(record.get('next_page_url')),flush=True)

def fetch_rest(key):
    record=RESULTS[key]
    seen={event['source_event_id'] for event in record['events']}
    urls_seen={c['url'] for c in record['source_checks'] if c['status']!='error'}
    mark_coverage(record)
    while record.get('next_page_url') and not record.get('requested_period_complete'):
        url=record['next_page_url']
        if url in urls_seen:
            record['stop_reason']='repeated_pagination_url';break
        offset=re.search(r'offset=(\d+)',url)
        suffix=offset.group(1) if offset else str(record['pages_collected'])
        raw=get(url,RAW/(key+'_history_'+suffix+'.html'),record['source_checks'])
        if raw is None:
            record['stop_reason']='page_fetch_failed';break
        events,next_url=parse(raw,url)
        new=[event for event in events if event['source_event_id'] not in seen]
        record['events'].extend(new)
        seen.update(event['source_event_id'] for event in new)
        urls_seen.add(url)
        record.update({'event_count':len(record['events']),'next_page_url':next_url,'history_complete':not bool(next_url),'pages_collected':record['pages_collected']+1})
        mark_coverage(record)
        save()
        print('page',key,suffix,'count',record['event_count'],'more',bool(next_url),flush=True)
        if not new and next_url:
            record['stop_reason']='no_new_events_with_next_link';break
        time.sleep(.2)
    save()

def main():
    addresses=json.loads((ROOT/'addresses.json').read_text())
    mapping={r['building_key']:r for r in json.loads((ROOT/'parts/vl_house_mapping.json').read_text())}
    old={r['building_key']:r for r in json.loads(OUTPUT.read_text())} if OUTPUT.exists() else {}
    for a in addresses:
        key=a['building_key']; m=mapping.get(key,{})
        if key in old and old[key].get('status')=='found':
            RESULTS[key]=old[key]
            mark_coverage(RESULTS[key])
            continue
        RESULTS[key]={'building_key':key,'requested_address':a['address'],'matched_address':m.get('matched_address'),
                      'vl_house_id':m.get('vl_house_id'),'match_status':m.get('match_status','pending'),
                      'status':'pending' if m.get('match_status')=='matched' else m.get('match_status','pending'),
                      'source_url':m.get('story_url'),'events':[],'event_count':0,'source_checks':[],
                      'history_complete':False,'coverage_note':'All reachable history pages are followed; missing records are not evidence of no outages.'}
    save()
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        list(pool.map(fetch_first,[m for m in mapping.values() if RESULTS[m['building_key']]['status']!='found']))
    for record in RESULTS.values(): mark_coverage(record)
    save()
    print('FIRST_PAGES_COMPLETE',flush=True)
    if '--first-only' in sys.argv:
        return
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        list(pool.map(fetch_rest,[k for k,r in RESULTS.items() if r.get('next_page_url') and not r.get('requested_period_complete')]))
    print('DONE',len(RESULTS),sum(r['event_count'] for r in RESULTS.values()),flush=True)

if __name__=='__main__':
    main()
