"""Extract only the selected house from the map embedded in its public page."""
import concurrent.futures
import datetime as dt
import json
import math
from pathlib import Path
import urllib.request
from urllib.parse import urljoin

from bs4 import BeautifulSoup

ROOT = Path(__file__).resolve().parents[1]


def distance(a, b):
    p1,p2 = map(math.radians, (a['lat'], b['lat']))
    dp,dl = p2-p1,math.radians(b['lon']-a['lon'])
    v = math.sin(dp/2)**2+math.cos(p1)*math.cos(p2)*math.sin(dl/2)**2
    return round(6371000*2*math.asin(min(1,math.sqrt(v))))


def collect(pair):
    house,mapping=pair
    key=house['building_key']
    row={'building_key':key,'matched_address':mapping['matched_address'],
         'source_type':'secondary_address_directory','fetched_at':dt.datetime.now(dt.timezone.utc).isoformat()}
    try:
        html=(ROOT/'raw'/'outages'/(key+'_building.html')).read_text()
        page=BeautifulSoup(html,'html.parser')
        map_node=page.select_one('.off-map[data-url]')
        if not map_node:raise ValueError('No published map URL on house page')
        url=urljoin(mapping['building_url'],map_node['data-url'])
        row['source_url']=url
        path=ROOT/'raw'/'maps'/(key+'.html')
        path.parent.mkdir(parents=True,exist_ok=True)
        if path.exists():data=path.read_bytes()
        else:
            with urllib.request.urlopen(url,timeout=30) as response:data=response.read()
            path.write_bytes(data)
        soup=BeautifulSoup(data,'html.parser')
        cfg=json.loads(soup.select_one('script.map-config').get_text())
        payload=json.loads(cfg['data']) if isinstance(cfg['data'],str) else cfg['data']
        building=payload['building']
        if building['address']!=mapping['matched_address']:
            raise ValueError('Map selected house address does not match matched house')
        lon,lat=building['coordinates']
        if not (isinstance(lon,(int,float)) and isinstance(lat,(int,float)) and -180<=lon<=180 and -90<=lat<=90):
            raise ValueError('Invalid map coordinates')
        row.update({'status':'found','coordinates':{'lat':lat,'lon':lon},
                    'coordinates_precision':'Address map marker; entrance accuracy not established',
                    'published_current_blackout_ids':building.get('blackouts',[]),
                    'published_current_claims':building.get('claims',[]),
                    'claims_note':'Source display only; resident reports are not independently verified',
                    'distances_from_listing_coordinates_m':[distance(x,{'lat':lat,'lon':lon}) for x in house['coordinates_from_listings']]})
    except Exception as exc:row.update({'status':'unavailable','error':type(exc).__name__+': '+str(exc)})
    return row


if __name__=='__main__':
    houses=json.loads((ROOT/'addresses.json').read_text())
    mapping={x['building_key']:x for x in json.loads((ROOT/'parts/vl_house_mapping.json').read_text())}
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        rows=list(pool.map(collect,[(x,mapping[x['building_key']]) for x in houses]))
    (ROOT/'parts'/'coordinates.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
    print(json.dumps({'houses':len(rows),'found':sum(r['status']=='found' for r in rows),
                      'failures':[{'building_key':r['building_key'],'error':r.get('error')} for r in rows if r['status']!='found'],
                      'disagreements_over_200m':[{'building_key':r['building_key'],'distances_m':r.get('distances_from_listing_coordinates_m')} for r in rows if any(x>200 for x in r.get('distances_from_listing_coordinates_m',[]))]},ensure_ascii=False))
