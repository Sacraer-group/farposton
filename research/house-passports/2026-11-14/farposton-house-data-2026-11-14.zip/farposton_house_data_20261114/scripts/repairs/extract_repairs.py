"""Read the downloaded official FKR XLS files; never modify the workbooks."""
from pathlib import Path
from collections import defaultdict
from datetime import datetime, timezone
import json
import re
import urllib.parse
import xlrd

BASE = Path(__file__).resolve().parents[2]
RAW = BASE / "raw" / "repairs"
CHECKED_AT = datetime.now(timezone.utc).isoformat()
REGIONAL_URL = "https://fkr25.ru/files/2014-2088/" + urllib.parse.quote("Электронная база данных.xls")
FORM1_URL = "https://fkr25.ru/files/2026-2028/" + urllib.parse.quote("Форма 1 2026-28.xls")
FORM2_URL = "https://fkr25.ru/files/2026-2028/" + urllib.parse.quote("Форма 2 2026-28.xls")
SOURCE_METADATA = {row["source_url"]: row for row in json.loads((RAW / "source_manifest.json").read_text())}


def norm_street(s):
    s = s.casefold().replace("ё", "е").strip()
    s = re.sub(r"^(улица|ул\.?)[ ]+", "ул ", s)
    s = re.sub(r"^(проспект|пр-кт\.?|пр-т\.?)[ ]+", "пр ", s)
    s = re.sub(r"^(переулок|пер\.?)[ ]+", "пер ", s)
    # Ordinals may precede or follow a street name; the numbered street is retained.
    s = re.sub(r"^(ул|пр|пер) (.+) (\d+-я)$", r"\1 \3 \2", s)
    return re.sub(r"[\s.,]+", "", s)


def norm_house(s):
    s = str(s).casefold().replace("ё", "е")
    s = re.sub(r"\b(?:корпус|корп\.?|кор\.?|к\.)\s*", "к", s)
    return re.sub(r"[\s.,]+", "", s)


def source_key(address):
    m = re.match(r"^г\.\s*Владивосток,\s*(.+),\s*д\.\s*(.+)$", address.strip(), re.I)
    return (norm_street(m[1]), norm_house(m[2])) if m else None


def target_key(address):
    m = re.match(r"^(.+?)\s+(\d+[а-яa-z]?(?:/\d+[а-яa-z]?)?(?:\s+(?:кор\.?|корпус|корп\.?|к\.)\s*\d+[а-яa-z]?)?)$", address, re.I)
    if not m:
        raise ValueError("Unparsed target address: " + address)
    return norm_street(m[1]), norm_house(m[2])


def read_index(filename):
    sh = xlrd.open_workbook(RAW / filename).sheet_by_index(0)
    result = defaultdict(list)
    year = None
    for i in range(sh.nrows):
        row = sh.row_values(i)
        if row[0] in (2026, 2027, 2028) and not row[1]:
            year = int(row[0])
        key = source_key(str(row[1]))
        if key:
            result[key].append({"row": i + 1, "values": row, "year_section": year, "sheet": sh.name})
    return result, sh


def clean(v):
    if v == "":
        return None
    if isinstance(v, float) and v.is_integer():
        return int(v)
    return v.strip() if isinstance(v, str) else v


def build():
    targets = json.loads((BASE / "addresses.json").read_text())
    regional, regional_sheet = read_index("regional_program.xls")
    form1, _ = read_index("plan_2026_2028_form1.xls")
    form2, form2_sheet = read_index("plan_2026_2028_form2.xls")
    rows = []
    for target in targets:
        key = target_key(target["address"])
        matches = regional.get(key, [])
        record = {
            "building_key": target["building_key"], "input_address": target["address"],
            "matched_address": matches[0]["values"][1] if len(matches) == 1 else None,
            "match_status": "found" if len(matches) == 1 else "ambiguous" if matches else "not_found",
            "works": [], "building_fields": {}, "short_term_plan": [], "source_rows": [],
            "source_checks": [
                {"url": REGIONAL_URL, "status": "retrieved", "checked_at": CHECKED_AT, "document_date": "2026-10-13", "matched_rows": [m["row"] for m in matches]},
                {"url": FORM1_URL, "status": "retrieved", "checked_at": CHECKED_AT, "document_date": "2026-05-28", "matched_rows": [m["row"] for m in form1.get(key, [])]},
                {"url": FORM2_URL, "status": "retrieved", "checked_at": CHECKED_AT, "document_date": "2026-05-28", "matched_rows": [m["row"] for m in form2.get(key, [])]},
            ],
            "coverage_note": "Regional programme 2014–2088, revision linked on official site as 2026-10-13; short-term plan 2026–2028 linked as 2026-05-28. Programme periods do not establish completion. Missing rows do not establish absence of a repair obligation."
        }
        if len(matches) != 1:
            record["same_street_candidates"] = [m["values"][1] for k, ms in regional.items() if k[0] == key[0] for m in ms]
        if len(matches) == 1:
            m = matches[0]
            values = m["values"]
            record["source_rows"].append({"source_url": REGIONAL_URL, **m})
            for name, col in [("year_commissioned", 2), ("last_major_repair_year_reported", 3), ("wall_material", 4), ("floors_total", 5), ("entrances", 6), ("building_area_m2", 7), ("premises_area_m2", 8)]:
                record["building_fields"][name] = {"value": clean(values[col]), "source_url": REGIONAL_URL, "source_row": m["row"], "document_date": "2026-10-13", "fetched_at": CHECKED_AT}
            for col in range(9, 24):
                value = clean(values[col])
                if value is None:
                    continue
                header = regional_sheet.cell_value(5, col) or regional_sheet.cell_value(4, col)
                record["works"].append({"kind": re.sub(r"\s+", " ", str(header)).strip(), "planned_period": value, "status_reported": "scheduled_in_regional_programme", "source_url": REGIONAL_URL, "document_date": "2026-10-13", "source_row": m["row"], "source_column": col + 1, "fetched_at": CHECKED_AT})
        for m in form1.get(key, []):
            record["source_rows"].append({"source_url": FORM1_URL, **m})
            v = m["values"]
            record["short_term_plan"].append({"year": m["year_section"], "planned_completion": v[12], "funding_method_reported": v[13], "planned_cost_rub": clean(v[8]), "source_url": FORM1_URL, "source_row": m["row"], "document_date": "2026-05-28"})
        for m in form2.get(key, []):
            record["source_rows"].append({"source_url": FORM2_URL, **m})
            for col in range(3, 18):
                value = clean(m["values"][col])
                if value is None:
                    continue
                header = form2_sheet.cell_value(5, col) or form2_sheet.cell_value(4, col)
                record["works"].append({"kind": re.sub(r"\s+", " ", str(header)).strip(), "planned_period": m["year_section"], "planned_cost_rub": value, "status_reported": "scheduled_in_short_term_plan", "source_url": FORM2_URL, "source_row": m["row"], "source_column": col + 1, "document_date": "2026-05-28", "fetched_at": CHECKED_AT})
        rows.append(record)
    # Preserve source retrieval time separately from this parsing/checking time.
    for record in rows:
        for value in [*record["works"], *record["building_fields"].values(), *record["short_term_plan"]]:
            value["fetched_at"] = SOURCE_METADATA[value["source_url"]]["retrieved_at"]
    (BASE / "parts" / "repairs.json").write_text(json.dumps(rows, ensure_ascii=False, indent=2))
    print(json.dumps({"addresses": len(rows), "regional_matches": sum(r["match_status"] == "found" for r in rows), "short_term_matches": sum(bool(r["short_term_plan"]) for r in rows), "work_records": sum(len(r["works"]) for r in rows), "unmatched": [(r["building_key"], r["input_address"], r.get("same_street_candidates", [])) for r in rows if r["match_status"] != "found"]}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    build()
