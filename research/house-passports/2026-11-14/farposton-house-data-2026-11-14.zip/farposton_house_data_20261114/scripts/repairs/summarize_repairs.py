"""Validate the address-bound extract and record coverage without inferring missing facts."""
from collections import Counter
from datetime import datetime, timezone
import json
from extract_repairs import BASE, RAW, SOURCE_METADATA, source_key, target_key

path = BASE / "parts" / "repairs.json"
rows = json.loads(path.read_text())
targets = {r["building_key"]: r for r in json.loads((BASE / "addresses.json").read_text())}
assert len(rows) == len(targets) == 48
assert len({r["building_key"] for r in rows}) == 48
assert {r["building_key"] for r in rows} == set(targets)
assert target_key("улица Ульяновская 12/1") != source_key("г. Владивосток, ул. Ульяновская, д. 12")
assert target_key("улица Авроровская 6 кор. 1") != source_key("г. Владивосток, ул. Авроровская, д. 6")
assert target_key("улица Майора Филипова 10 кор. 1") != target_key("улица Майора Филипова 10 кор. 2")
assert target_key("улица Поселковая 3-я 22 кор. 1") == source_key("г. Владивосток, ул. 3-я Поселковая, д. 22к1")
assert target_key("проспект Красного Знамени 133/1") == source_key("г. Владивосток, пр-кт. Красного Знамени, д. 133/1")

floor_conflicts = []
for row in rows:
    if row["match_status"] == "found":
        assert target_key(row["input_address"]) == source_key(row["matched_address"])
    assert {c["year"] for c in row["execution_checks"]} == set(range(2017, 2027))
    assert len(row["execution_checks"]) == 10
    for check in row["execution_checks"]:
        if check["status"] == "found":
            assert source_key(check["matched_address"]) == target_key(row["input_address"])
    for item in [*row["works"], *row["building_fields"].values(), *row["short_term_plan"]]:
        metadata = SOURCE_METADATA.get(item["source_url"])
        if metadata:
            item["fetched_at"] = metadata["retrieved_at"]
    for work in row["works"]:
        assert work["source_url"] and work["source_row"] and work["kind"]
        assert work["planned_period"] is not None
    for plan in row["short_term_plan"]:
        work_cost = sum(w["planned_cost_rub"] for w in row["works"] if w["status_reported"] == "scheduled_in_short_term_plan" and w["planned_period"] == plan["year"])
        assert round(work_cost, 2) == round(plan["planned_cost_rub"], 2), (row["building_key"], plan["year"], work_cost)
    official = row["building_fields"].get("floors_total", {}).get("value")
    listed = sorted({o["floors_total"] for o in targets[row["building_key"]]["offers"] if o.get("floors_total") is not None})
    if official is not None and listed and any(n != official for n in listed):
        floor_conflicts.append({"building_key": row["building_key"], "address": row["input_address"], "fkr_floors_reported": official, "listing_floors_reported": listed, "fkr_source": row["building_fields"]["floors_total"], "note": "Source disagreement; not a proven error. Floor-counting conventions may differ."})

path.write_text(json.dumps(rows, ensure_ascii=False, indent=2))
execution = [w for row in rows for w in row["works"] if w.get("source_type") == "execution_page"]
log = json.loads((RAW / "execution_fetch_log.json").read_text())
summary = {
    "generated_at": datetime.now(timezone.utc).isoformat(),
    "addresses_checked": len(rows),
    "regional_programme_exact_matches": sum(row["match_status"] == "found" for row in rows),
    "regional_work_observations": sum(w["status_reported"] == "scheduled_in_regional_programme" for row in rows for w in row["works"]),
    "short_term_houses": sum(bool(row["short_term_plan"]) for row in rows),
    "short_term_work_observations": sum(w["status_reported"] == "scheduled_in_short_term_plan" for row in rows for w in row["works"]),
    "execution_years_checked": list(range(2017, 2027)),
    "execution_houses_with_work_rows": sum(any(w.get("source_type") == "execution_page" for w in row["works"]) for row in rows),
    "execution_work_observations": len(execution),
    "execution_work_rows_reported_complete": sum(str(w["status_reported"]).startswith("Работы выполнены") for w in execution),
    "execution_work_rows_without_reported_completion": sum(w["status_reported"] == "---" for w in execution),
    "execution_check_statuses": dict(Counter(c["status"] for row in rows for c in row["execution_checks"])),
    "http_failures_remaining": [r for r in log if r["status"] != "retrieved"],
    "regional_unmatched": [{"building_key": r["building_key"], "address": r["input_address"], "same_street_candidates": r["same_street_candidates"]} for r in rows if r["match_status"] != "found"],
    "floors_source_conflicts": floor_conflicts,
    "short_term_houses_detail": [{"building_key": r["building_key"], "address": r["input_address"], "plans": r["short_term_plan"]} for r in rows if r["short_term_plan"]],
    "limitations": [
        "All 48 addresses checked; not all source facts are available for every address.",
        "Regional and short-term programmes are plans, not evidence of completion.",
        "Execution statuses are quoted source reports, not independent inspection; year is the page/programme year, not an exact completion date.",
        "A '---' status is unknown, not a determination that work was not performed.",
        "Missing address in any file or year does not establish absence of repair plans or repairs.",
        "12 HTTP 403 responses remain. No workaround was attempted. Six transient 503 responses recovered on one retry.",
        "Execution lists checked for published years 2017–2026 only. There is no claim of full lifetime history.",
        "Document edition dates come from official index link descriptions. The source XLS files retain their own original headings.",
        "Cost fields are whole-building plan or reported execution costs in rubles, not tenant utility expenses.",
        "Work observations may overlap across programme and execution sources and must not be added as independent repairs."
    ],
    "validation": {
        "all_48_unique_building_keys": "passed",
        "exact_address_links_preserve_corpus_letter_slash": "passed",
        "ten_execution_year_checks_per_building": "passed",
        "five_normalization_boundary_checks": "passed",
        "short_term_work_cost_sums_equal_form1_totals": "passed"
    }
}
(BASE / "parts" / "repairs_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2))
print(json.dumps({k: v for k, v in summary.items() if k not in {"http_failures_remaining", "floors_source_conflicts", "short_term_houses_detail", "regional_unmatched"}}, ensure_ascii=False, indent=2))
