"""Collect the official public FKR execution forms discovered from their page JS."""
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import re
import time
import urllib.parse
import urllib.request
from bs4 import BeautifulSoup
from extract_repairs import BASE, RAW, norm_house, norm_street, source_key, target_key

ORIGIN = "https://fkr25.ru"
CACHE = RAW / "execution"
CACHE.mkdir(exist_ok=True)
LOG = []
PREVIOUS_LOG = RAW / "execution_fetch_log.json"
PREVIOUS_ERRORS = {
    row["url"]: row
    for row in json.loads(PREVIOUS_LOG.read_text())
    if row.get("status") != "retrieved"
} if PREVIOUS_LOG.exists() else {}


def fetch(url, as_json=False):
    key = hashlib.sha256(url.encode()).hexdigest()[:20]
    path = CACHE / (key + (".json" if as_json else ".txt"))
    checked_at = datetime.now(timezone.utc).isoformat()
    try:
        if path.exists():
            data = path.read_bytes()
            checked_at = datetime.fromtimestamp(path.stat().st_mtime, timezone.utc).isoformat()
        elif url in PREVIOUS_ERRORS and "403" in PREVIOUS_ERRORS[url].get("error", ""):
            # Retain the access-denied result; do not retry or bypass it.
            result = PREVIOUS_ERRORS[url]
            LOG.append(result)
            return None, result
        else:
            with urllib.request.urlopen(url, timeout=35) as resp:
                data = resp.read()
            path.write_bytes(data)
            time.sleep(.3)
        value = json.loads(data) if as_json else data.decode("utf-8", "replace")
        result = {"url": url, "status": "retrieved", "checked_at": checked_at, "file": str(path.relative_to(BASE)), "bytes": len(data)}
        LOG.append(result)
        return value, result
    except Exception as error:
        result = {"url": url, "status": "error", "checked_at": checked_at, "error": str(error)}
        LOG.append(result)
        return None, result


def endpoint(path, params):
    return urllib.parse.urljoin(ORIGIN, path) + "?" + urllib.parse.urlencode(params)


def inspect_year(path):
    page_url = urllib.parse.urljoin(ORIGIN, path)
    html, page_check = fetch(page_url)
    if html is None:
        return {"page_url": page_url, "checks": [page_check], "error": "page_unavailable"}
    soup = BeautifulSoup(html, "html.parser")
    year = int(soup.select_one("#rep_year")["value"])
    scripts = [s["src"] for s in soup.select("script[src]") if "RepairProgram" in s["src"]]
    script, js_check = fetch(urllib.parse.urljoin(page_url, scripts[0]))
    if script is None:
        return {"page_url": page_url, "year": year, "checks": [page_check, js_check], "error": "script_unavailable"}
    paths = re.findall(r'\$\.getJSON\("([^\"]+)"', script)
    api = {p.rsplit("/", 1)[-1]: p for p in paths}
    towns = {a.get("data-gorod") for a in soup.select("#gorod a")}
    if "г. Владивосток" not in towns:
        return {"page_url": page_url, "year": year, "checks": [page_check, js_check], "error": "town_not_listed"}
    streets, streets_check = fetch(endpoint(api["getstreet"], {"id": "г. Владивосток", "year": year}), True)
    return {"page_url": page_url, "year": year, "api": api, "streets": streets, "checks": [page_check, js_check, streets_check]}


def main():
    targets = json.loads((BASE / "addresses.json").read_text())
    results = json.loads((BASE / "parts" / "repairs.json").read_text())
    by_key = {target_key(t["address"]): t["building_key"] for t in targets}
    by_id = {r["building_key"]: r for r in results}
    for r in results:
        r["works"] = [w for w in r["works"] if w.get("source_type") != "execution_page"]
        r["execution_checks"] = []
    index = BeautifulSoup((RAW / "execution_index.html").read_text(), "html.parser")
    paths = [a["href"] for a in index.select("a[href]") if re.fullmatch(r"/RepairProgram\d{4}", a["href"])]
    years = []
    with ThreadPoolExecutor(3) as pool:
        for f in as_completed([pool.submit(inspect_year, path) for path in paths]):
            result = f.result()
            years.append(result)
            print("year discovered", result.get("year"), result.get("error"), flush=True)
    house_queries = []
    for info in years:
        year = info.get("year")
        if not isinstance(info.get("streets"), list):
            for record in results:
                record["execution_checks"].append({"year": year, "status": "source_unavailable", "source_checks": info["checks"]})
            continue
        wanted_streets = {norm_street(s["street"]): s for s in info["streets"] if norm_street(s["street"]) in {k[0] for k in by_key}}
        for key, building_key in by_key.items():
            if key[0] not in wanted_streets:
                by_id[building_key]["execution_checks"].append({"year": year, "status": "street_not_listed_in_year", "source_url": info["checks"][-1]["url"], "checked_at": info["checks"][-1]["checked_at"]})
        for street_key, street in wanted_streets.items():
            house_queries.append((info, street_key, street, endpoint(info["api"]["gethouse"], {"street": street["street"], "town": street["town"], "year": year})))
    details_queries = []
    with ThreadPoolExecutor(3) as pool:
        futures = {pool.submit(fetch, query[3], True): query for query in house_queries}
        for n, f in enumerate(as_completed(futures), 1):
            info, street_key, street, url = futures[f]
            houses, check = f.result()
            for key, building_key in by_key.items():
                if key[0] != street_key:
                    continue
                if not isinstance(houses, list):
                    by_id[building_key]["execution_checks"].append({"year": info["year"], "status": "source_unavailable", "source_checks": [check]})
                    continue
                exact = [h for h in houses if norm_house(h["house"]) == key[1]]
                if len(exact) != 1:
                    by_id[building_key]["execution_checks"].append({"year": info["year"], "status": "not_listed_in_year" if not exact else "ambiguous", "source_url": url, "checked_at": check["checked_at"]})
                else:
                    detail_url = endpoint(info["api"]["getaddress"], {"id": exact[0]["id"], "year": info["year"]})
                    details_queries.append((building_key, info, exact[0], detail_url))
            if n % 10 == 0:
                print("street lists", n, "/", len(futures), flush=True)
    with ThreadPoolExecutor(3) as pool:
        futures = {pool.submit(fetch, query[3], True): query for query in details_queries}
        for f in as_completed(futures):
            building_key, info, house, url = futures[f]
            records, check = f.result()
            record = by_id[building_key]
            if not isinstance(records, list) or not records:
                record["execution_checks"].append({"year": info["year"], "status": "source_unavailable", "source_checks": [check]})
                continue
            for details in records:
                address = details.get("fool_addres")
                parsed_key = source_key(address) if address else None
                if parsed_key and parsed_key != target_key(record["input_address"]):
                    record["execution_checks"].append({"year": info["year"], "status": "address_conflict", "returned_address": address, "source_url": url})
                    continue
                record["execution_checks"].append({"year": info["year"], "status": "found", "matched_address": address, "source_house_id": house["id"], "source_url": url, "checked_at": check["checked_at"]})
                for index, work in enumerate(details.get("works", []), 1):
                    record["works"].append({"kind": work.get("name"), "planned_period": info["year"], "status_reported": work.get("stat"), "status_column_label": "Выполнено", "source_type": "execution_page", "source_url": url, "source_page_url": info["page_url"], "document_date": None, "source_row": index, "source_house_id": house["id"], "fetched_at": check["checked_at"]})
                print("detail", building_key, info["year"], address, len(details.get("works", [])), flush=True)
    for record in results:
        record["execution_checks"].sort(key=lambda x: x.get("year") or 0)
        note = " Execution forms checked for published years 2017–2026. Missing address in a yearly form is not evidence that no work occurred. Execution status is the source's report, not independent inspection."
        if note not in record["coverage_note"]:
            record["coverage_note"] += note
    (BASE / "parts" / "repairs.json").write_text(json.dumps(results, ensure_ascii=False, indent=2))
    (RAW / "execution_fetch_log.json").write_text(json.dumps(LOG, ensure_ascii=False, indent=2))
    print(json.dumps({"targets": len(results), "year_forms": len(years), "street_requests": len(house_queries), "house_detail_requests": len(details_queries), "houses_with_execution_records": sum(any(w.get("source_type") == "execution_page" for w in r["works"]) for r in results), "execution_work_records": sum(w.get("source_type") == "execution_page" for r in results for w in r["works"]), "failed_requests": sum(x["status"] != "retrieved" for x in LOG)}, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
