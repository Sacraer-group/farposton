"""Merge manually reviewed public source claims; do not resolve conflicting managers."""
import json
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
RAW = ROOT / 'raw/management'
PARTS = ROOT / 'parts'
BASE = PARTS / 'management_vl_only.json'
if not BASE.exists():
    BASE.write_bytes((PARTS / 'management.json').read_bytes())
rows = json.loads(BASE.read_text())
by_key = {x['building_key']: x for x in rows}

def stamp(raw):
    return datetime.fromtimestamp((ROOT / raw).stat().st_mtime, timezone.utc).isoformat()

S1 = 'raw/management/supplementary_web_reads.txt'
S2 = 'raw/management/supplementary_web_reads_2.txt'
S3 = 'raw/management/final_supplementary_reads.txt'
S4 = 'raw/management/conflict_and_okatovaya.txt'
ORG_COMFORT = 'https://dompassport.ru/org/uk-tekhnologiya-komforta-vladivostok/'

claims = [
    dict(key='B002', name='НО ТСЖ «АЛЬЯНС»', slug='100-letiya-vladivostoka-120a', phone='+7 (423) 231-65-53', dispatch='+7 (423) 231-65-53', website='https://xn--80alqfdcved8h7a.xn--80asb2ahb.xn--p1ai/', contract='2005-04-22', raw=S1),
    dict(key='B007', name='ООО «УК ЛИДЕР-СЕРВИС»', slug='admirala-gorshkova-52k2', phone='+7 (423) 239-71-07, +7 924 009-13-76', dispatch='+7 914 320-66-56, +7 951 019-94-42', website='https://uk-lider-servis.ru/', contract='2024-03-01', raw=S2),
    dict(key='B008', name='ТСН «МОЛОДЕЖНЫЙ»', slug='admirala-gorshkova-8', phone='+7 908 449-55-02', dispatch='+7 924 720-24-70', contract='2023-12-15', raw=S1),
    dict(key='B027', name='ООО УК «ТЕХНОЛОГИЯ КОМФОРТА»', url=ORG_COMFORT, phone='+7 914 967-66-15', email='tehcom-uk@yandex.ru', address='Приморский край, г. Владивосток, ул. Ивановская, д. 15', inn='2536352343', ogrn='1252500023654', raw=S4, match='exact_house_in_organization_service_list'),
    dict(key='B029', name='ООО УК «ТЕХНОЛОГИЯ КОМФОРТА»', slug='mayora-filipova-11k1', phone='+7 914 967-66-15', contract='2026-09-01', raw=S1),
    dict(key='B030', name='ООО «РЕНЕССАНС КОМФОРТ»', slug='makovskogo-55k2', phone='+7 (423) 239-34-03, +7 924 007-24-42', dispatch='+7 (423) 239-34-03, +7 924 007-24-42, +7 984 212-87-07', website='https://www.rencomfort.ru/', contract='2025-10-08', raw=S3),
    dict(key='B034', name='ООО «УК »РАССВЕТ', slug='okatovaya-18', phone='+7 914 791-12-92', dispatch='+7 914 663-07-09, +7 914 702-86-32, +7 (423) 206-03-20', contract='2025-11-01', raw=S4),
    dict(key='B037', name='ООО УК «АКВАТОРИЯ ДОМ»', url='https://dompassport.ru/org/uk-akvatoriya-dom/', phone='+7 951 013-12-22', dispatch='+7 (423) 298-09-81', email='akuatoria-dom@yandex.ru', address='Приморский край, г. Владивосток, ул. 3-я Поселковая, д. 22, корп. 1', inn='2540285918', ogrn='1242500015735', raw=S2, match='exact_house_in_organization_service_list'),
    dict(key='B042', name='ООО УК «ТЕХНОЛОГИЯ КОМФОРТА»', url=ORG_COMFORT, phone='+7 914 967-66-15', email='tehcom-uk@yandex.ru', address='Приморский край, г. Владивосток, ул. Ивановская, д. 15', inn='2536352343', ogrn='1252500023654', raw=S4, match='exact_house_in_organization_service_list'),
    dict(key='B043', name='ООО «РЕНЕССАНС КОМФОРТ»', slug='tretya-7a', phone='+7 (423) 239-34-03, +7 924 007-24-42', dispatch='+7 (423) 239-34-03, +7 924 007-24-42, +7 984 212-87-07', website='https://www.rencomfort.ru/', contract='2020-11-01', raw=S2),
]
supplements = []
for c in claims:
    row = by_key[c['key']]
    url = c.get('url') or f"https://dompassport.ru/dom/vladivostok/{c['slug']}/"
    t = stamp(c['raw'])
    org = {
        'name': c['name'], 'role': 'Управляющая организация',
        'phone': c['phone'], 'dispatch_phone': c.get('dispatch'),
        'email': c.get('email'), 'address': c.get('address'), 'website': c.get('website'),
        'inn': c.get('inn'), 'ogrn': c.get('ogrn'),
        'source_url': url, 'relationship_source': url,
        'source_type': 'secondary_aggregator', 'scope': 'house_specific',
        'relationship_status': 'published_claim_not_primary_verified',
        'match_basis': c.get('match', 'exact_address_house_page'),
        'contract_start_claimed': c.get('contract'),
        'source_as_of_claimed': '2026-10-10' if c.get('slug') else None,
        'fetched_at': t, 'raw_file': c['raw'], 'phone_tested_by_call': False,
    }
    if c['key'] == 'B029':
        org['additional_evidence'] = [{
            'source_url': ORG_COMFORT, 'source_type': 'secondary_aggregator',
            'fetched_at': stamp(S4), 'raw_file': S4,
            'inn': '2536352343', 'ogrn': '1252500023654',
            'email': 'tehcom-uk@yandex.ru',
            'address': 'Приморский край, г. Владивосток, ул. Ивановская, д. 15',
        }]
    row['organizations'].append(org)
    row['source_checks'].append({'url': url, 'status': 'retrieved_via_web', 'checked_at': t, 'raw_file': c['raw'], 'error': None})
    supplements.append({'building_key': c['key'], 'organization_claim': org})

primary_checks = json.loads((RAW / 'primary_access_checks.json').read_text())
for row in rows:
    row['source_checks'].append(primary_checks[0])
    row['management_status'] = 'published_claim' if any(x['role'] == 'Управляющая организация' for x in row['organizations']) else 'not_found_in_checked_sources'
    row['primary_verification_status'] = 'not_verified_gis_unavailable'
    row['coverage_note'] = 'Данные VL.ru и Домпаспорт — опубликованные сведения вторичных источников; звонком контакты не проверены. Городские аварийные службы не приравниваются к поставщикам конкретного дома.'
    for field in row['building_fields'].values():
        field['verification_status'] = 'published_claim_not_primary_verified'

for key in ['B027', 'B029', 'B042']:
    row = by_key[key]
    row['management_status'] = 'conflict_unresolved'
    row['conflicts'] = [{
        'field': 'management_organization', 'status': 'unresolved',
        'claims': [{
            'name': x['name'], 'source_url': x['relationship_source'],
            'contract_start_claimed': x.get('contract_start_claimed'),
            'source_as_of_claimed': x.get('source_as_of_claimed'),
            'fetched_at': x['fetched_at'],
        } for x in row['organizations'] if x['role'] == 'Управляющая организация'],
        'organization_identity_evidence': [
            {'name': 'АО «Технология управления»', 'inn': '2543125768', 'ogrn': '1182536016960', 'source_url': 'https://saby.ru/profile/2543125768-253601001', 'source_type': 'secondary_business_directory', 'fetched_at': stamp(S3), 'raw_file': S3},
            {'name': 'ООО УК «ТЕХНОЛОГИЯ КОМФОРТА»', 'inn': '2536352343', 'ogrn': '1252500023654', 'source_url': ORG_COMFORT, 'source_type': 'secondary_aggregator', 'fetched_at': stamp(S4), 'raw_file': S4},
        ],
        'note': 'Источники называют разные юридические лица. Смена УК или действующий договор не подтверждены первоисточником. Не выбирать одну организацию автоматически.',
    }]

for key in ['B030', 'B043']:
    row = by_key[key]
    row['organization_primary_evidence'] = [{
        'url': 'https://rencomfort.ru/about/docs',
        'status': 'indexed_primary_page_full_fetch_failed',
        'claim': 'На официальном сайте проиндексирован план подготовки к отопительному периоду 2026–2027 для точного адреса этого дома.',
        'title': 'План подготовки к отопительному периоду 2026-2027гг. ' + ('Маковского д. 55 корпус 2' if key == 'B030' else 'ул. Третья д. 7а'),
        'source_type': 'organization_official_site_search_index',
        'checked_at': stamp('raw/management/final_three_searches.txt'),
        'raw_file': 'raw/management/final_three_searches.txt',
        'note': 'Полный документ не получен; это дополнительная связь с адресом, а не проверка действующего договора управления.',
    }]
    row['source_checks'].append({'url': 'https://rencomfort.ru/about/docs', 'status': 'fetch_error', 'checked_at': stamp('raw/management/official_management_reads.txt'), 'error': '502 Bad Gateway', 'raw_file': 'raw/management/official_management_reads.txt'})
for key, url in [('B007','https://uk-lider-servis.ru/'), ('B002','https://xn--80alqfdcved8h7a.xn--80asb2ahb.xn--p1ai/')]:
    by_key[key]['source_checks'].append({'url':url, 'status':'fetch_error', 'checked_at':stamp('raw/management/official_management_reads.txt') if key == 'B007' else '2026-11-13', 'checked_at_precision':'timestamp' if key == 'B007' else 'day', 'error':'502 Bad Gateway'})

by_key['B006']['unmatched_candidates'] = [{
    'matched_address': 'Владивосток, ул. Авроровская, д. 6',
    'source_url': 'https://ossdoc.ru/mkd/primorskiy-kray/vladivostok/ul-avrorovskaya-6',
    'status': 'rejected_address_mismatch',
    'reason': 'В источнике отсутствует корпус 1; тождество с адресом объявления не доказано. УК дома 6 не присвоена корпусу 1.',
}]
by_key['B023']['search_note'] = 'Точная связь Лесная 153в корпус 3 с УК/ТСЖ не найдена. Сведения о Лесной 153д и соседних корпусах к этому дому не присоединялись.'
for key in ['B006','B023']:
    by_key[key]['search_checks'] = [{
        'query_scope': 'Точный адрес с литерой и корпусом, УК/ТСЖ/управляющая организация',
        'status': 'no_reliable_exact_management_match',
        'checked_at': stamp(S3),
        'raw_files': ['raw/management/final_three_searches.txt', S3],
    }]

summary = {
    'generated_at': datetime.now(timezone.utc).isoformat(),
    'total_requested':48,
    'exact_vl_address_matches': sum(x['match_status']=='matched' for x in rows),
    'houses_with_any_management_claim':sum(any(o['role']=='Управляющая организация' for o in x['organizations']) for x in rows),
    'management_status_counts':dict(Counter(x['management_status'] for x in rows)),
    'houses_without_management_claim':[x['building_key'] for x in rows if x['management_status']=='not_found_in_checked_sources'],
    'houses_with_conflicting_management_claims':[x['building_key'] for x in rows if x['management_status']=='conflict_unresolved'],
    'houses_with_published_house_specific_organization':sum(bool(x['organizations']) for x in rows),
    'houses_with_commissioning_year_from_vl':sum('commissioning_year' in x['building_fields'] for x in rows),
    'houses_with_floors_from_vl':sum('floors' in x['building_fields'] for x in rows),
    'houses_with_any_vl_fields':sum(bool(x['building_fields']) for x in rows),
    'supplemented_house_keys':[x['building_key'] for x in supplements],
    'primary_management_contracts_verified':0,
    'limitations':[
        'Первичные договоры/реестр действующего управления не проверены: ГИС ЖКХ вернула 503.',
        'Сведения вторичных справочников могут запаздывать. Три противоречия требуют отдельной проверки.',
        '48 карточек с любыми полями не означают 48 полных паспортов: часть содержит только опубликованную информацию о подключении ресурсов.',
        'Официальные характеристики 44 домов лежат в parts/repairs.json; при объединении их следует хранить вместе с происхождением каждого поля.',
        'Общегородской справочник аварийных служб сохранён отдельно от домовых организаций.',
        'Число отсутствующих организаций не означает отсутствие УК в действительности.',
    ],
}
assert len(rows)==48 and len(by_key)==48
assert set(by_key)=={f'B{i:03d}' for i in range(1,49)}
assert all(x['match_status']=='matched' for x in rows)
assert all(o.get('relationship_source') for x in rows for o in x['organizations'])
for path,data in [(PARTS/'management.json',rows),(PARTS/'management_supplements.json',supplements),(PARTS/'management_coverage.json',summary)]:
    path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(summary,ensure_ascii=False,indent=2))
