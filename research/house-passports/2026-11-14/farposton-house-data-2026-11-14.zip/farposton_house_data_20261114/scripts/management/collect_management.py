"""Collect publicly published house facts and contacts; preserve source scope."""
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import re
import time
import urllib.request
from bs4 import BeautifulSoup

ROOT = Path(__file__).resolve().parents[2]
RAW = ROOT / 'raw' / 'management'
RAW.mkdir(parents=True, exist_ok=True)
FIELDS = {
    'Почтовый индекс': 'postal_code',
    'Ввод в эксплуатацию': 'commissioning_year',
    'Материал стен': 'wall_material',
    'Количество этажей': 'floors',
    'Количество подъездов': 'entrances',
    'Общая площадь МКД': 'building_area',
    'Площадь помещений МКД': 'premises_area',
    'Управляющая компания': 'management_organization',
    'Центральное отопление': 'central_heating',
    'Горячее водоснабжение': 'hot_water_supply',
    'Холодное водоснабжение': 'cold_water_supply',
}

def now():
    return datetime.now(timezone.utc).isoformat()

def get(url, name):
    path = RAW / (name + '.html')
    meta_path = RAW / (name + '.meta.json')
    if path.exists() and meta_path.exists():
        return BeautifulSoup(path.read_bytes(), 'html.parser'), json.loads(meta_path.read_text())
    check = {'url': url, 'checked_at': now(), 'source_type': 'secondary_address_directory'}
    try:
        with urllib.request.urlopen(url, timeout=25) as r:
            body = r.read()
            check.update(status='fetched', http_status=r.status, final_url=r.url,
                         sha256=hashlib.sha256(body).hexdigest(), error=None)
        path.write_bytes(body)
        check['raw_file'] = str(path.relative_to(ROOT))
        meta_path.write_text(json.dumps(check, ensure_ascii=False, indent=2))
        return BeautifulSoup(body, 'html.parser'), check
    except Exception as e:
        check.update(status='fetch_error', error=f'{type(e).__name__}: {e}')
        return None, check

def contact(cell, role, url, checked_at, scope):
    lines = [p.get_text(' ', strip=True) for p in cell.find_all('p', recursive=False)]
    if not lines:
        lines = [cell.get_text(' ', strip=True)]
    links = [a for a in cell.select('a[href]') if '/off/management-company/' in a['href']]
    email = list(dict.fromkeys(re.findall(r'[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}', ' '.join(lines))))
    phones = [x for x in lines if len(re.sub(r'\D', '', x)) >= 7 and not re.search(r'Владивосток|\bул\.|\bг\.|улиц|офис|дом №', x, re.I) and '@' not in x]
    addresses = [x for x in lines if re.search(r'Владивосток|улиц|\bул\.|офис|дом №', x, re.I) and x not in phones]
    return {
        'name': links[0].get_text(' ', strip=True) if links else (lines[0] if lines else None),
        'role': role,
        'phone': '\n'.join(phones) or None,
        'email': '; '.join(email) or None,
        'address': '\n'.join(addresses) or None,
        'website': None,
        'directory_url': urllib.parse.urljoin('https://www.vl.ru', links[0]['href']) if links else None,
        'source_url': url,
        'relationship_source': url if scope == 'house_specific' else None,
        'source_type': 'secondary_address_directory',
        'scope': scope,
        'fetched_at': checked_at,
        'contact_lines': lines,
        'phone_tested_by_call': False,
    }

def collect(pair):
    address, match = pair
    key = address['building_key']
    result = {'building_key': key, 'requested_address': address['address'],
              'matched_address': match.get('matched_address') if match else None,
              'match_status': match.get('match_status') if match else 'pending_mapping',
              'building_fields': {}, 'organizations': [], 'city_service_contacts': [],
              'source_checks': list(match.get('source_checks', [])) if match else [],
              'primary_verification_status': 'not_verified'}
    if not match or not match.get('vl_house_id') or match.get('match_status') != 'matched':
        return result
    hid = str(match['vl_house_id'])
    result['vl_house_id'] = hid
    for kind in ['info', 'contacts']:
        url = match.get(kind + '_url') or f'https://www.vl.ru/off/b/{kind}/{hid}'
        soup, check = get(url, f'{key}_{kind}')
        result['source_checks'].append(check)
        if soup is None:
            continue
        heading = soup.select_one('h1.building__heading')
        if heading is None:
            check['status'] = 'unexpected_page'
            continue
        result['source_address'] = heading.get_text(' ', strip=True)
        normal_title = lambda x: re.sub(r'\s+', ' ', x or '').strip().casefold().replace('ё', 'е')
        if normal_title(result['source_address']) != normal_title(result['matched_address']):
            check['status'] = 'address_mismatch'
            result['match_status'] = 'requires_review'
            continue
        if kind == 'info':
            for tr in soup.select('table.info__table tr'):
                cells = tr.find_all('td', recursive=False)
                if len(cells) != 2:
                    continue
                label, value = [c.get_text(' ', strip=True) for c in cells]
                if label in FIELDS and value:
                    result['building_fields'][FIELDS[label]] = {
                        'value': value, 'label_ru': label, 'source_url': url,
                        'source_type': 'secondary_address_directory', 'fetched_at': check['checked_at'],
                    }
        else:
            section = None
            for body in soup.select('table.contacts__table > tbody'):
                title = body.find('h2')
                if title:
                    section = title.get_text(' ', strip=True)
                    continue
                for tr in body.find_all('tr', recursive=False):
                    cells = tr.find_all('td', recursive=False)
                    if len(cells) != 2:
                        continue
                    role = cells[0].get_text(' ', strip=True)
                    if not role:
                        continue
                    if section == 'Организации обслуживающие дом':
                        if role == 'Руководитель':
                            continue
                        result['organizations'].append(contact(cells[1], role, url, check['checked_at'], 'house_specific'))
                    elif section == 'Городские аварийные и диспетчерские службы':
                        result['city_service_contacts'].append(contact(cells[1], role, url, check['checked_at'], 'city_directory_not_confirmed_house_provider'))
        time.sleep(0.25)
    return result

def main():
    addresses = json.loads((ROOT / 'addresses.json').read_text())
    matches = json.loads((ROOT / 'parts' / 'vl_house_mapping.json').read_text())
    if isinstance(matches, dict):
        matches = matches.get('records', matches.get('matches', []))
    by = {r['building_key']: r for r in matches}
    results = {}
    target = ROOT / 'parts' / 'management.json'
    with ThreadPoolExecutor(max_workers=3) as pool:
        work = [pool.submit(collect, (address, by.get(address['building_key']))) for address in addresses]
        for f in as_completed(work):
            result = f.result()
            results[result['building_key']] = result
            temp = target.with_suffix('.tmp')
            temp.write_text(json.dumps([results[k] for k in sorted(results)], ensure_ascii=False, indent=2))
            temp.replace(target)
            print(result['building_key'], result['match_status'], len(result['building_fields']), len(result['organizations']), flush=True)
    print('TOTAL', len(results), 'WITH_FIELDS', sum(bool(r['building_fields']) for r in results.values()), 'WITH_ORGS', sum(bool(r['organizations']) for r in results.values()), flush=True)

if __name__ == '__main__':
    main()
